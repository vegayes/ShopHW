package edu.hw.shop.inventory.model.vo;

public class Product {
	
	// 필드
	// PR_ID, CATEGORY , PR_NAME, INVENTORY, ACCOUNT, PRICE
	
	private String productId;
	private String category;
	private String productName;
	private int inventory;
	private String account;
	private int price;
	
	public Product() {}

	public Product(String productId, String category, String productName, int inventory, String account, int price) {
		super();
		this.productId = productId;
		this.category = category;
		this.productName = productName;
		this.inventory = inventory;
		this.account = account;
		this.price = price;
	}

	
	// getter / setter
	public String getProductId() {
		return productId;
	}

	public void setProductId(String productId) {
		this.productId = productId;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public int getInventory() {
		return inventory;
	}

	public void setInventory(int inventory) {
		this.inventory = inventory;
	}

	public String getAccount() {
		return account;
	}

	public void setAccount(String account) {
		this.account = account;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	// toString 설정안하면, 정보들이 출력되지 않음.
	@Override
	public String toString() {
		return "Product [물품Id = " + productId + ", 카테고리 = " + category + ", 물품명 = " + productName
				+ ", 재고 = " + inventory + ", 거래처 = " + account + ", 가격 = " + price + "]";
		
	}
	
	
	
	
	
	
	
	
	
	

}
