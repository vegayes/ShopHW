package edu.hw.shop.inventory.model.vo;

public class Member {
	
	
	private String memId ;
	private String memPw ;
	private String memName ;
	private long memBirthday ;
	private String memAddress ;
	private int memPurchase ;
	private String memGrade ="없음";
	

	public Member() {}

	public Member(String memId, String memPw, String memName, long memBirthday, String memAddress, int memPurchase /*,String memGrade*/) {
		super();
		this.memId = memId;
		this.memPw = memPw;
		this.memName = memName;
		this.memBirthday = memBirthday;
		this.memAddress = memAddress;
		this.memPurchase = memPurchase;
		if(memPurchase < 5) {
			this.memGrade = "일반";
		}else if ( memPurchase < 20 ) {
			this.memGrade = "골드";
		}else {
			this.memGrade = "VIP";
		}		
	}
	

	public String getMemId() {
		return memId;
	}

	public void setMemId(String memId) {
		this.memId = memId;
	}

	public String getMemPw() {
		return memPw;
	}

	public void setMemPw(String memPw) {
		this.memPw = memPw;
	}

	public String getMemName() {
		return memName;
	}

	public void setMemName(String memName) {
		this.memName = memName;
	}

	public long getMemBirthday() {
		return memBirthday;
	}

	public void setMemBirthday(int memBirthday) {
		this.memBirthday = memBirthday;
	}

	public String getMemAddress() {
		return memAddress;
	}

	public void setMemAddress(String memAddress) {
		this.memAddress = memAddress;
	}

	public int getMemPurchase() {
		return memPurchase;
	}

	public void setMemPurchase(int memPurchase) {
		this.memPurchase = memPurchase;
	}

	public String getMemGrade() {
		return memGrade;
	}

	public void setMemGrade(String memGrade) {
		this.memGrade = memGrade;
	}

	@Override
	public String toString() {
		return "회원 정보 [회원 ID = " + memId + ", 회원 Pw = " + memPw + ", 회원 이름 = " + memName + ", 회원 생년월일 = " + memBirthday
				+ ", 회원 주소 = " + memAddress + ", 회원 구매이력 = " + memPurchase + ", 회원 등급 = " + memGrade + "]";
	}
	
	
	
	
	
	

}
