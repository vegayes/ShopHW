package edu.hw.shop.inventory.model.service;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

import edu.hw.shop.inventory.model.vo.Product;
import edu.hw.shop.inventory.model.vo.Member;

public class InventoryService {
	
	private Scanner sc = new Scanner(System.in);
	
	private List <Product> productList = new ArrayList<Product>();
	private List <Member> memberList = new ArrayList<Member>();
	
	public InventoryService() {
			
		// 물품 저장
			productList.add(new Product("1","상의","반팔", 1, "KH", 25000));
			productList.add(new Product("2","하의","청바지", 2, "KH", 25000));
			productList.add(new Product("3","상의","긴팔", 3, "KH", 55000));
			productList.add(new Product("4","하의","카고 바지", 1, "KH", 45000));
			productList.add(new Product("5","원피스","체크", 2, "KH", 35000));
			productList.add(new Product("6","원피스","땡땡이", 0 , "KH", 35000));
			productList.add(new Product("7","ACC","하트", 0 , "KH", 35000));
			productList.add(new Product("8","ACC","다이아몬드", 10 , "KH", 55000));
			
		// 회원 저장
			memberList.add(new Member("user01", "pass01", "푸바오", 200720, "경기도 용인시", 10));
			memberList.add(new Member("user02", "pass02", "아이바오", 130713, "서울 종로구", 50));
			memberList.add(new Member("user03", "pass03", "러바오", 120728, "서울 서초구", 20));
			memberList.add(new Member("user04", "pass04", "꿔바로우", 010320, "충남 천안시", 4));
	}

	
	public void displayProduct() {
		
		int menuNum = 0;
		
		do {
			
			System.out.println("====== SHOP Management ======");
			System.out.println("1. 물품 정보");
			System.out.println("2. 회원 정보");
			System.out.println("0. 프로그램 종료");
			
			System.out.print("메뉴 선택 >> ");
			
			
			try {
				menuNum =sc.nextInt();
				System.out.println()
				;
				switch(menuNum) {
		
				case 1: productInfo(); break;
				case 2: MemberInfo(); break;
				case 0: System.out.println("SHOP Management 프로그램을 종료합니다."); break;
				default: System.out.println(" 메뉴에 있는 숫자를 입력해주세요."); break;
		
				}
			}catch(InputMismatchException e){
				
				System.out.println("Error! 입력 형식이 유효하지 않습니다.");
				sc.nextLine();
				
				menuNum = -1;
			}catch(Exception e) {
				e.printStackTrace();
			}
			
		}while(menuNum !=0);
	
		
	}
	
		
		
	public void productInfo() throws InputMismatchException {

		int prNum = 0;
		
		do {
			System.out.println("\n==== 물품 정보 메뉴 선택 ====");
			System.out.println("1. 물품 정보 추가");
			System.out.println("2. 물품 전체 조회");
			System.out.println("3. 물품 정보 수정");
			System.out.println("4. 물품 정보 제거");
			System.out.println("5. 카테고리 별 검색 ");
			System.out.println("0. 처음으로 돌아가기");
			
			System.out.print("메뉴 선택 >>");
	
			prNum = sc.nextInt();
			System.out.println();
			
			switch(prNum) {
			case 1: System.out.println(addProduct()); break;
			case 2: updateProduct(); break;
			case 3: System.out.println(replaceProduct()); break;
			case 4: System.out.println(removeProduct()); break;
			case 5: searchCategory(); break;
			case 0: System.out.println(); break;
			default: System.out.println(" 메뉴에 있는 숫자를 입력해주세요."); break;
			}	
		}while(prNum != 0);
	}


	public String addProduct() throws InputMismatchException {

		System.out.println("\n==== 물품 정보 추가 ====");
		
		System.out.print("추가 물품 ID : ");
		String addPrID = sc.next();
		
		System.out.print("추가 물품 카테고리 : ");
		String addPrCategory = sc.next();
		
		System.out.print("추가 물품명 : ");
		String addPrName = sc.next();
		
		System.out.print("추가 재고 수량 : ");
		int addInventory = sc.nextInt();
		
		sc.nextLine();
		
		System.out.print("거래처 : ");
		String addAccount = sc.nextLine();
		
		System.out.print("추가 물품 가격 : ");
		int addPrice = sc.nextInt();
	
// --> ID가 같으면 다시 하라고 하기. continue
		
		for(int i = 0 ; i < productList.size(); i++) {
			
			if(productList.get(i).getProductId().equals(addPrID)) {

				return "동일한 ID 존재.. 실패!";
			}
		}

		if(productList.add(new Product(addPrID,addPrCategory,addPrName,addInventory,addAccount,addPrice))) {

			return "성공";

		}else {
			
			return "실패";
		}
		
	}
	
	public void updateProduct() {
		
		System.out.println("\n==== 물품 정보 조회 ====");
		
		for(Product pr : productList) {		
			System.out.println(pr);		
		}
	}
	
	public String replaceProduct() throws InputMismatchException{// + 수정할 값만 변경하기.
		
		System.out.println("\n==== 물품 정보 수정 ====");
		
		System.out.println("현재 물품 정보");
		updateProduct();
		
		System.out.print("\n수정 할 물품 ID 입력 :");
		String rePrId = sc.next();

		if(productList.isEmpty()) { // list 담겨있는지 확인.
			return "등록된 물품의 정보가 없습니다.";
		}else {
		 // ID가 같은지 확인.
			for(int i = 0 ; i < productList.size(); i++) {
				
				if(productList.get(i).getProductId().equals(rePrId)) {
					
					System.out.println(productList.get(i));
					
					System.out.print("변경 물품 ID : ");
					String rePrID = sc.next();
					//rePrId = sc.next();
					
					System.out.print("변경 물품 카테고리 : ");
					String rePrCategory = sc.next();
					
					System.out.println(rePrCategory);
					
					System.out.print("변경 물품명 : ");
					String rePrName = sc.next();
					
					System.out.print("변경 재고 수량 : ");
					int reInventory = sc.nextInt();
					
					sc.nextLine();
					
					System.out.print("변경 거래처 : ");
					String reAccount = sc.nextLine();
					
					System.out.print("변경 물품 가격 : ");
					int rePrice = sc.nextInt();
					
					Product temp = productList.set(i, 
								new Product(rePrID,rePrCategory,rePrName,reInventory,reAccount,rePrice)); 				
					return "수정완료";
				}
			}		
			return"일치하는 물품의 ID가 존재하지 않습니다.";	
		}	
	}
	
	public String removeProduct() throws InputMismatchException {
		System.out.println("\n==== 물품 삭제 ====");
		
		System.out.println("현재 물품 정보");
		updateProduct();
		
		System.out.print("\n삭제 할 물품 ID 입력 :");
		String removePrId = sc.next();

		if(productList.isEmpty()) { // list 담겨있는지 확인.
			return "등록된 물품의 정보가 없습니다.";
		}else {
			for(int i = 0 ; i < productList.size(); i++) {
				
				if(productList.get(i).getProductId().equals(removePrId)) {
					
					System.out.println(productList.get(i));
					
					System.out.print("\n정말로 삭제하시겠습니까? (Y/N) >> ");
					char check = sc.next().toUpperCase().charAt(0);
					
					if(check == 'Y') {
						Product temp = productList.remove(i);
						return "물품ID" + temp.getProductId() + "가 삭제되었습니다.";
					}else {
						return "취소되었습니다.";
					}
				}
			}		
			return"일치하는 물품의 ID가 존재하지 않습니다.";	
		}	
	}

	private void searchCategory() throws InputMismatchException {
		System.out.println("\n==== 카테고리 별 검색 ====");
		
		int sum = 0;
		int sumCategory = 0;
		
		boolean flag = false;
		
		System.out.print("\n검색 할 물품의 카테고리 입력 :");
		String srCategory = sc.next();

		if(productList.isEmpty()) { // list 담겨있는지 확인.
			System.out.println("등록된 물품의 정보가 없습니다.");
		}else {
		 // ID가 같은지 확인.
			for(int i = 0 ; i < productList.size(); i++) {
				
				if(productList.get(i).getCategory().equals(srCategory)) {	
					
					System.out.println(productList.get(i));
					
					sum = productList.get(i).getInventory() * 
							productList.get(i).getPrice();
					
					sumCategory += sum;
					sum = 0;
						
					flag = true;
					System.out.println();
				}	
			}		
			
			if(flag = true) {
				System.out.println(srCategory + "의 재고 총 금액 : " + sumCategory);
			}else {
				System.out.println("검색하신 카테고리는 존재하지 않습니다.");
			}
		}	
	}
	
	
	//----------------------------------- 회원 정보 --------------------------------
	public void MemberInfo() {
		
		int memberNum = 0;
		
		do {
			System.out.println("\n==== 회원 정보 메뉴 선택 ====");
			System.out.println("1. 회원 정보 추가");
			System.out.println("2. 회원 전체 조회");
			System.out.println("3. 회원 정보 수정");
			System.out.println("4. 회원 정보 제거");
			System.out.println("5. 등급 별 검색 ");
			System.out.println("0. 처음으로 돌아가기");
			
			System.out.print("메뉴 선택 >>");
	
			memberNum = sc.nextInt();
			System.out.println();
			
			switch(memberNum) {
			case 1: System.out.println(addMember()); break;
			case 2: updateMember(); break;
			case 3: System.out.println(replaceMember()); break;
			case 4: System.out.println(removeMember()); break;
			case 5: searchGrade(); break;
			case 0: System.out.println(); break;
			default: System.out.println(" 메뉴에 있는 숫자를 입력해주세요."); break;
			}	
		}while(memberNum != 0);
		
		
	}
	
	public String addMember() {

		System.out.println("\n==== 회원 정보 추가 ====");
		
		System.out.print("추가 회원 ID : ");
		String memId = sc.next();
		
		System.out.print("추가 회원 Pw : ");
		String memPw = sc.next();
		
		System.out.print("추가 회원명 : ");
		String memName = sc.next();
		
		System.out.print("추가 회원 생년월일 : ");
		int memBirthday = sc.nextInt();
		
		sc.nextLine();
		
		System.out.print("추가 회원 주소 : ");
		String memAddress = sc.nextLine();
		
		System.out.print("추가 회원 구매 내역 : ");
		int memPurchase = sc.nextInt();
		
		
		for(int i = 0 ; i < memberList.size(); i++) {
			
			if(memberList.get(i).getMemId().equals(memId)) {

				return "동일한 ID 존재.. 실패!";
			}
		}

		if(memberList.add(new Member(memId,memPw,memName,memBirthday,memAddress,memPurchase))) {

			return "성공";

		}else {
			
			return "실패";
		}
	}
	
	
	public void updateMember() {
		
		System.out.println("\n==== 회원 정보 조회 ====");
		
		for(Member mem : memberList) {		
			System.out.println(mem);		
		}
	}
	
	public String replaceMember() throws InputMismatchException{// + 수정할 값만 변경하기.
		
		System.out.println("\n==== 회원 정보 수정 ====");
		
		System.out.println("현재 회원 정보");
		updateMember();
		
		System.out.print("\n수정 할 회원 ID 입력 :");
		String reMemId = sc.next();

		if(productList.isEmpty()) { // list 담겨있는지 확인.
			return "등록된 회원의 정보가 없습니다.";
		}else {
		 // ID가 같은지 확인.
			for(int i = 0 ; i < memberList.size(); i++) {
				
				if(memberList.get(i).getMemId().equals(reMemId)) {
					
					System.out.println(memberList.get(i));
					
					System.out.print("수정 회원 ID : ");
					String reMemID = sc.next();
					//rePrId = sc.next();
					
					System.out.print("수정 회원 Pw : ");
					String reMemPw = sc.next();
					
					System.out.print("수정 회원명 : ");
					String reMemName = sc.next();
					
					System.out.print("수정 회원 생년월일 : ");
					int reMemBirthday = sc.nextInt();
					
					sc.nextLine();
					
					System.out.print("수정 회원 주소 : ");
					String reMemAddress = sc.nextLine();
					
					System.out.print("수정 회원 구매 내역 : ");
					int reMemPurchase = sc.nextInt();
					
					Member temp = memberList.set(i, 
								new Member(reMemID,reMemPw,reMemName,reMemBirthday,reMemAddress,reMemPurchase)); 				
					return "수정완료";
				}
			}		
			return"일치하는 회원의 ID가 존재하지 않습니다.";	
		}	
	}
	
	public String removeMember() throws InputMismatchException {
		System.out.println("\n==== 회원 삭제 ====");
		
		System.out.println("현재 회원 정보");
		updateMember();
		
		System.out.print("\n삭제 할 회원 ID 입력 :");
		String removeMemId = sc.next();

		if(memberList.isEmpty()) { // list 담겨있는지 확인.
			return "등록된 회원의 정보가 없습니다.";
		}else {
			for(int i = 0 ; i < memberList.size(); i++) {
				
				if(memberList.get(i).getMemId().equals(removeMemId)) {
					
					System.out.println(memberList.get(i));
					
					System.out.print("\n정말로 삭제하시겠습니까? (Y/N) >> ");
					char check = sc.next().toUpperCase().charAt(0);
					
					if(check == 'Y') {
						Member temp = memberList.remove(i);
						return "회원ID" + temp.getMemId() + "가 삭제되었습니다.";
					}else {
						return "취소되었습니다.";
					}
				}
			}		
			return"일치하는 회원의 ID가 존재하지 않습니다.";	
		}	
	}

	private void searchGrade() throws InputMismatchException {
		System.out.println("\n==== 등급 별 검색 ====");
		
		boolean flag = false;
		
		System.out.print("\n검색 할 등급 입력 :");
		String srGrade = sc.next();

		if(memberList.isEmpty()) { 
			System.out.println("등록된 회원의 정보가 없습니다.");
		}else {
			for(int i = 0 ; i < memberList.size(); i++) {
				
				if(memberList.get(i).getMemGrade().equals(srGrade)) {	
					
					System.out.println(memberList.get(i));
						
					flag = true;
				}	
			}
			
			if(!flag) {
			System.out.println("검색하신 등급은 존재하지 않습니다.");
			}
		}	
	}

}	
