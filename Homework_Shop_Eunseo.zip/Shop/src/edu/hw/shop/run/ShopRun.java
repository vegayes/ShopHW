package edu.hw.shop.run;

import edu.hw.shop.inventory.model.service.InventoryService;

public class ShopRun {
	
	public static void main(String[] args) {
		
		InventoryService service = new InventoryService();
		
		service.displayProduct();

	}
	

}
